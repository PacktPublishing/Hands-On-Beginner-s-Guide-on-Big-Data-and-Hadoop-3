# Hands-On-Beginner-s-Guide-on-Big-Data-and-Hadoop-3-
Hands-On Beginner’s Guide on Big Data and Hadoop 3 [Video], published by Packt
